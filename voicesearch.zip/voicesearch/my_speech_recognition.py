import io
import os

# Imports the Google Cloud client library
from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types
from google.oauth2 import service_account
import pyaudio


import speech_recognition as sr
import datetime


class SpeechRecognition:

    @staticmethod
    def transcript(file_path):
        r = sr.Recognizer()
        file = sr.AudioFile(file_path)


        with file as source:
            audio = r.record(source)
            print(f'sphinx: {r.recognize_sphinx(audio)}')
            print(f'google: {r.recognize_google(audio)}')
            #print(f'google cloud: {r.recognize_google_cloud(audio, credentials)}')
            #print(f'bing: {r.recognize_bing(audio )}')
            #print(f'houndify: {r.recognize_houndify(audio)}')
            #print(f'ibm: {r.recognize_ibm(audio)}')
            #print(f'wit: {r.recognize_wit(audio)}')

    @staticmethod
    def transcript():
        r = sr.Recognizer()
        with sr.Microphone() as source:
            print('say something...')
            r.adjust_for_ambient_noise(source)
            audio = r.listen(source)
            print('Okay, I heard you. Let me process it...')
            start_time = datetime.datetime.now()

            print(f'sphinx: {r.recognize_sphinx(audio)}')
            end_time_sphinx = datetime.datetime.now()
            print(f'Time Taken: {(end_time_sphinx - start_time).total_seconds()} seconds')

            print(f'google: {r.recognize_google(audio)}')
            end_time_google = datetime.datetime.now()
            print(f'Time Taken: {(end_time_google - start_time).total_seconds()} seconds')
