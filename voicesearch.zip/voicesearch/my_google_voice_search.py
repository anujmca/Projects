import io
import os

# Imports the Google Cloud client library
from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types
import speech_recognition as sr
import datetime


class GoogleVoiceSearch:

    @staticmethod
    def transcript(file_path):
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "VoiceSearch-0f0d55cb68a9.json"

        # using Google Voice Search
        # Instantiates a client
        client = speech.SpeechClient()


        # Loads the audio into memory
        with io.open(file_path, 'rb') as audio_file:
            content = audio_file.read()
            audio = types.RecognitionAudio(content=content)


        config = types.RecognitionConfig(
            encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
            #sample_rate_hertz=48000,
            #language_code='hi-IN',
            language_code='en-IN'
        )

        # Detects speech in the audio file
        response = client.recognize(config, audio)

        print(f'response: {len(response.results)}')

        for result in response.results:
            print('Transcript: {}'.format(result.alternatives[0].transcript))


    @staticmethod
    def transcript():
        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = "VoiceSearch-0f0d55cb68a9.json"

        # using Google Voice Search
        # Instantiates a client
        client = speech.SpeechClient()

        r = sr.Recognizer()
        with sr.Microphone() as source:
            print('say something...')
            r.adjust_for_ambient_noise(source)
            content = r.listen(source)
            print('Okay, I heard you. Let me process it...')
            audio = types.RecognitionAudio(content=content.get_wav_data())

        config = types.RecognitionConfig(
            encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
            # sample_rate_hertz=48000,
            # language_code='hi-IN',
            language_code='en-IN'
        )

        start_time = datetime.datetime.now()
        # Detects speech in the audio file
        response = client.recognize(config, audio)
        end_time_google = datetime.datetime.now()

        print(f'response: {len(response.results)}')

        transcripts = []
        for result in response.results:
            transcripts.append(result.alternatives[0].transcript)
            print('Transcript: {}'.format(result.alternatives[0].transcript))
        print(f'Time Taken: {(end_time_google - start_time).total_seconds()} seconds')
        return transcripts



class TwoChannelToMono:

    @staticmethod
    def convert(input_file_path, output_file_path):
        from pydub import AudioSegment
        sound = AudioSegment.from_wav(input_file_path)
        sound = sound.set_channels(1)
        sound.export(output_file_path, format="wav")
